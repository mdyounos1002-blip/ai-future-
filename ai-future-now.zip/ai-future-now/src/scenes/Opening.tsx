import React from "react";
import {AbsoluteFill, Easing, interpolate, random, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {C} from "../theme";
import {fontFamily} from "../fonts";
import {CL, easeOut, shake, toBn} from "../fx";
import {Kinetic} from "../ui";

/** 0–3s: light line → flare → IMPACT → glowing title "AI — ভবিষ্যৎ এখন". */
export const Opening: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();

  const lineW = interpolate(f, [2, 24], [0, 100], {...CL, easing: Easing.out(Easing.cubic)});
  const lineO = interpolate(f, [30, 60], [1, 0.35], CL);
  const flare = interpolate(f, [24, 30, 56], [0, 1, 0.25], CL);
  const pct = Math.floor(interpolate(f, [4, 28], [0, 100], CL));
  const counterO = interpolate(f, [2, 6, 28, 36], [0, 1, 1, 0], CL);

  const sh = shake(f, 30, 12, 14);
  const cam = interpolate(f, [0, 90], [1, 1.1], CL);

  const t = spring({frame: f - 30, fps, config: {damping: 18, stiffness: 140}});
  const titleScale = interpolate(t, [0, 1], [1.7, 1]);
  const titleBlur = interpolate(f, [30, 48], [26, 0], CL);
  const titleO = interpolate(f, [30, 33], [0, 1], CL);
  const tracking = interpolate(f, [30, 75], [0.5, 0.08], {...CL, easing: Easing.out(Easing.cubic)});

  const g = f >= 30 && f < 38 ? 22 * (1 - (f - 30) / 8) : f >= 64 && f < 68 ? 8 : 0;
  const dx = (random(`g${f}`) - 0.5) * 2 * g;

  const dash = interpolate(f, [44, 58], [0, 150], {...CL, easing: Easing.out(Easing.cubic)});

  const titleStyle: React.CSSProperties = {
    fontFamily,
    fontWeight: 800,
    fontSize: 430,
    lineHeight: 1,
    letterSpacing: `${tracking}em`,
    paddingLeft: `${tracking}em`,
    position: "absolute",
    left: 0,
    right: 0,
    textAlign: "center",
  };

  const ring = (delay: number) => {
    const r = interpolate(f, [30 + delay, 62 + delay], [40, 950], {...CL, easing: easeOut});
    const o = interpolate(f, [30 + delay, 62 + delay], [0.9, 0], CL);
    return (
      <div
        style={{
          position: "absolute",
          left: 540 - r,
          top: 880 - r,
          width: r * 2,
          height: r * 2,
          borderRadius: "50%",
          border: `3px solid ${C.cyan}`,
          boxShadow: `0 0 40px ${C.blue}, inset 0 0 40px ${C.blue}`,
          opacity: f >= 30 + delay ? o : 0,
        }}
      />
    );
  };

  return (
    <AbsoluteFill style={{transform: `translate(${sh.x}px, ${sh.y}px) scale(${cam})`, transformOrigin: "540px 900px"}}>
      {/* anamorphic flare */}
      <div
        style={{
          position: "absolute",
          left: -200,
          top: 880 - 130,
          width: 1480,
          height: 260,
          background: "radial-gradient(ellipse at center, rgba(120,200,255,0.95) 0%, rgba(30,144,255,0.5) 30%, transparent 70%)",
          opacity: flare,
          transform: "scaleY(0.35)",
          filter: "blur(14px)",
        }}
      />
      {/* horizontal light line */}
      <div
        style={{
          position: "absolute",
          left: `${50 - lineW / 2}%`,
          width: `${lineW}%`,
          top: 880,
          height: f < 30 ? 3 : 5,
          background: "linear-gradient(90deg, transparent, #fff, transparent)",
          boxShadow: `0 0 30px 6px ${C.cyan}`,
          opacity: lineO,
        }}
      />
      {ring(0)}
      {ring(7)}

      {/* loading counter */}
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 960,
          textAlign: "center",
          fontFamily,
          fontWeight: 700,
          fontSize: 46,
          color: C.cyan,
          opacity: counterO,
          textShadow: `0 0 20px ${C.cyan}`,
        }}
      >
        সিস্টেম লোড হচ্ছে {toBn(pct)}%
      </div>

      {/* title */}
      <div style={{position: "absolute", left: 0, right: 0, top: 560, height: 450}}>
        {g > 0 && (
          <>
            <div style={{...titleStyle, color: "#ff2d55", opacity: 0.75 * titleO, mixBlendMode: "screen", transform: `translateX(${dx}px) scale(${titleScale})`, filter: `blur(${titleBlur}px)`}}>AI</div>
            <div style={{...titleStyle, color: "#00c8ff", opacity: 0.75 * titleO, mixBlendMode: "screen", transform: `translateX(${-dx}px) scale(${titleScale})`, filter: `blur(${titleBlur}px)`}}>AI</div>
          </>
        )}
        <div
          style={{
            ...titleStyle,
            opacity: titleO,
            transform: `scale(${titleScale})`,
            filter: `blur(${titleBlur}px) drop-shadow(0 0 30px rgba(30,144,255,0.9)) drop-shadow(0 0 90px rgba(30,144,255,0.6))`,
            backgroundImage: "linear-gradient(180deg,#ffffff 25%,#8fd4ff 100%)",
            WebkitBackgroundClip: "text",
            backgroundClip: "text",
            color: "transparent",
          }}
        >
          AI
        </div>
      </div>

      {/* dash + Bangla title */}
      <div style={{position: "absolute", left: 0, right: 0, top: 1060, display: "flex", flexDirection: "column", alignItems: "center", gap: 6}}>
        <div style={{width: dash, height: 6, borderRadius: 3, background: C.cyan, boxShadow: `0 0 24px 4px ${C.cyan}`}} />
        <Kinetic text="ভবিষ্যৎ এখন" start={48} stagger={6} size={150} accent={[1]} />
      </div>
    </AbsoluteFill>
  );
};
