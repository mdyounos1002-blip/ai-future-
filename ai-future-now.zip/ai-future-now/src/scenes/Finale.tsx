import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {C} from "../theme";
import {fontFamily} from "../fonts";
import {CL} from "../fx";
import {Kinetic} from "../ui";

/** 27–30s: memorable closing title with light sweep. */
export const Finale: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const orb = spring({frame: f, fps, config: {damping: 14, stiffness: 90}});
  const line = interpolate(f, [30, 54], [0, 640], CL);
  const sweep = interpolate(f, [26, 54], [-300, 1200], CL);
  const brand = interpolate(f, [34, 48], [0, 0.8], CL);
  return (
    <AbsoluteFill>
      <div style={{position: "absolute", left: 0, right: 0, top: 360, display: "flex", justifyContent: "center", transform: `scale(${0.6 + 0.4 * Math.min(1, orb)})`, opacity: Math.min(1, orb)}}>
        <svg width={420} height={420} viewBox="-210 -210 420 420">
          <defs>
            <radialGradient id="fo">
              <stop offset="0%" stopColor="#fff" />
              <stop offset="40%" stopColor={C.cyan} />
              <stop offset="100%" stopColor={C.deep} stopOpacity={0} />
            </radialGradient>
          </defs>
          <circle r={190 + 8 * Math.sin(f / 8)} fill="url(#fo)" opacity={0.85} />
          <g transform={`rotate(${f * 1.5})`}>
            <circle r={170} fill="none" stroke="#9fe8ff" strokeWidth={5} strokeDasharray="200 870" strokeLinecap="round" style={{filter: "drop-shadow(0 0 12px #4fd8ff)"}} />
          </g>
          <circle r={150} fill="none" stroke={C.cyan} strokeWidth={2} strokeDasharray="3 14" opacity={0.7} />
          <text y={34} textAnchor="middle" fontSize={96} fontWeight={800} fill="#fff" style={{fontFamily, filter: "drop-shadow(0 0 16px #4fd8ff)"}}>AI</text>
        </svg>
      </div>

      <div style={{position: "absolute", left: 80, right: 80, top: 860, clipPath: "inset(-80px -80px -80px -80px)", display: "flex", flexDirection: "column", alignItems: "center", gap: 10}}>
        <Kinetic text="প্রযুক্তিকে জানুন," start={4} size={108} stagger={7} accent={[1]} />
        <Kinetic text="দায়িত্ব নিয়ে ব্যবহার করুন।" start={20} size={108} stagger={6} accent={[0]} accentColor="#fff" />
        <div style={{position: "absolute", top: -50, bottom: -50, left: sweep, width: 180, transform: "skewX(-20deg)", background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.6), transparent)", mixBlendMode: "screen", filter: "blur(10px)"}} />
      </div>

      <div style={{position: "absolute", left: 0, right: 0, top: 1380, display: "flex", justifyContent: "center"}}>
        <div style={{width: line, height: 4, borderRadius: 2, background: `linear-gradient(90deg, transparent, ${C.cyan}, transparent)`, boxShadow: `0 0 22px ${C.cyan}`}} />
      </div>
      <div style={{position: "absolute", left: 0, right: 0, top: 1420, textAlign: "center", fontFamily, fontWeight: 700, fontSize: 40, color: C.dim, opacity: brand}}>
        AI — ভবিষ্যৎ এখন
      </div>
    </AbsoluteFill>
  );
};
