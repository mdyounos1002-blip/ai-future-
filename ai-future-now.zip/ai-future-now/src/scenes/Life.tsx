import React from "react";
import {AbsoluteFill, Sequence, interpolate, random, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {C, LIFE} from "../theme";
import {fontFamily} from "../fonts";
import {CL, easeInOut, toBn} from "../fx";
import {LowerThird, Panel, Particles} from "../ui";

const BASE_BG = "radial-gradient(ellipse 90% 60% at 50% 35%, #06214f 0%, #030a1f 55%, #02040a 100%)";

/** Wipe-in with glowing edge; hides the previous vignette underneath. */
const Wipe: React.FC<{children: React.ReactNode; first?: boolean}> = ({children, first}) => {
  const f = useCurrentFrame();
  const p = first ? 1 : easeInOut(interpolate(f, [0, 12], [0, 1], CL));
  return (
    <>
      <AbsoluteFill style={{clipPath: `inset(0 ${(1 - p) * 100}% 0 0)`, background: BASE_BG}}>
        <Particles count={36} seed="life" speed={0.8} />
        {children}
      </AbsoluteFill>
      {!first && p < 1 && (
        <div style={{position: "absolute", top: 0, bottom: 0, left: `${p * 100}%`, width: 8, marginLeft: -8, background: "#fff", boxShadow: `0 0 50px 14px ${C.cyan}`}} />
      )}
    </>
  );
};

/* ---------------- A: healthcare — DNA helix + ECG ---------------- */
const beat = (u: number) => {
  if (u < 0.3) return 0;
  if (u < 0.36) return -14 * Math.sin(((u - 0.3) / 0.06) * Math.PI);
  if (u < 0.44) return 0;
  if (u < 0.47) return 18 * ((u - 0.44) / 0.03);
  if (u < 0.5) return 18 - 148 * ((u - 0.47) / 0.03);
  if (u < 0.53) return -130 + 160 * ((u - 0.5) / 0.03);
  if (u < 0.56) return 30 - 30 * ((u - 0.53) / 0.03);
  if (u < 0.7) return 0;
  if (u < 0.78) return -22 * Math.sin(((u - 0.7) / 0.08) * Math.PI);
  return 0;
};

const Health: React.FC = () => {
  const f = useCurrentFrame();
  const N = 30;
  const shown = interpolate(f, [0, 30], [0, N], CL);
  const zoom = interpolate(f, [0, 72], [1.05, 1.2], CL);
  const pts: string[] = [];
  for (let x = 0; x <= 1080; x += 6) pts.push(`${x},${1290 + beat((((x + f * 10) % 360) + 360) % 360 / 360)}`);
  const acc = interpolate(f, [8, 55], [60, 94.7], CL);
  return (
    <AbsoluteFill>
      <div style={{position: "absolute", left: 140, top: 300, width: 800, height: 800, borderRadius: "50%", background: "radial-gradient(circle, rgba(30,144,255,0.35), transparent 65%)"}} />
      <AbsoluteFill style={{transform: `scale(${zoom}) rotate(-14deg)`, transformOrigin: "540px 700px"}}>
        <svg width={1080} height={1920} viewBox="0 0 1080 1920">
          {Array.from({length: N}, (_, i) => {
            if (i > shown) return null;
            const y = 300 + i * 30;
            const ang = i * 0.42 + f * 0.07;
            const s = Math.sin(ang);
            const z = Math.cos(ang);
            const x1 = 540 + s * 190;
            const x2 = 540 - s * 190;
            return (
              <g key={i}>
                <line x1={x1} y1={y} x2={x2} y2={y} stroke={C.cyan} strokeWidth={2} opacity={0.2 + 0.2 * Math.abs(z)} />
                <circle cx={x1} cy={y} r={9 + 6 * z} fill="#8fe6ff" opacity={0.5 + 0.5 * (z + 1) / 2} style={{filter: "drop-shadow(0 0 8px #4fd8ff)"}} />
                <circle cx={x2} cy={y} r={9 - 6 * z} fill="#2f7dff" opacity={0.5 + 0.5 * (1 - z) / 2} style={{filter: "drop-shadow(0 0 8px #1e90ff)"}} />
              </g>
            );
          })}
        </svg>
      </AbsoluteFill>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: "absolute", inset: 0}}>
        <defs>
          <linearGradient id="ecgf" x1="0" x2="1">
            <stop offset="0" stopColor={C.cyan} stopOpacity={0} />
            <stop offset="0.3" stopColor={C.cyan} />
            <stop offset="0.8" stopColor="#fff" />
            <stop offset="1" stopColor={C.cyan} stopOpacity={0} />
          </linearGradient>
        </defs>
        <polyline points={pts.join(" ")} fill="none" stroke="url(#ecgf)" strokeWidth={5} strokeLinejoin="round" style={{filter: "drop-shadow(0 0 10px #4fd8ff)"}} />
      </svg>
      <Panel x={650} y={290} w={360} delay={10}>
        <div style={{fontSize: 28, opacity: 0.8}}>রোগ শনাক্তকরণ</div>
        <div style={{fontSize: 56, fontWeight: 800, color: C.cyan, textShadow: `0 0 20px ${C.cyan}`}}>{toBn(acc.toFixed(1))}%</div>
      </Panel>
      <LowerThird idx="০১" title="স্বাস্থ্যসেবা" sub="দ্রুত ও নির্ভুল রোগ শনাক্তকরণ" />
    </AbsoluteFill>
  );
};

/* ---------------- B: smart city + vision boxes ---------------- */
const mkCity = (seed: string, minH: number, maxH: number, minW: number, maxW: number) => {
  const out: {x: number; w: number; h: number; i: number}[] = [];
  let x = -60;
  let i = 0;
  while (x < 1500) {
    const w = minW + random(`${seed}w${i}`) * (maxW - minW);
    const h = minH + random(`${seed}h${i}`) * (maxH - minH);
    out.push({x, w, h, i});
    x += w + 4;
    i++;
  }
  return out;
};
const BACK = mkCity("b", 300, 720, 70, 130);
const MID = mkCity("m", 240, 560, 80, 140);
const FRONT = mkCity("f", 140, 380, 90, 160);

const CityLayer: React.FC<{b: typeof BACK; fill: string; base: number; dx: number; lit: number; seed: string; f: number}> = ({b, fill, base, dx, lit, seed, f}) => (
  <g transform={`translate(${dx},0)`}>
    {b.map((bd) => {
      const cols = Math.floor(bd.w / 28);
      const rows = Math.min(12, Math.floor(bd.h / 46));
      const wins: React.ReactNode[] = [];
      for (let r = 0; r < rows; r++)
        for (let c = 0; c < cols; c++)
          if (random(`${seed}${bd.i}-${r}-${c}`) > 0.6)
            wins.push(<rect key={`${r}-${c}`} x={bd.x + 10 + c * 28} y={base - bd.h + 14 + r * 46} width={12} height={18} fill={C.cyan} opacity={lit * (0.45 + 0.55 * Math.abs(Math.sin(f / 14 + r * 7 + c * 3 + bd.i)))} />);
      return (
        <g key={bd.i}>
          <rect x={bd.x} y={base - bd.h} width={bd.w} height={bd.h} fill={fill} />
          {wins}
        </g>
      );
    })}
  </g>
);

const CARS = [
  {lane: 0, dir: 1, sp: 9, off: 0.1, w: 150, box: true},
  {lane: 0, dir: 1, sp: 6.5, off: 0.55, w: 130, box: false},
  {lane: 1, dir: -1, sp: 8, off: 0.3, w: 140, box: true},
  {lane: 1, dir: -1, sp: 11, off: 0.8, w: 150, box: true},
  {lane: 0, dir: 1, sp: 12, off: 0.85, w: 140, box: false},
];

const City: React.FC = () => {
  const f = useCurrentFrame();
  const zoom = interpolate(f, [0, 73], [1.0, 1.08], CL);
  return (
    <AbsoluteFill>
      <div style={{position: "absolute", left: 190, top: 150, width: 700, height: 700, borderRadius: "50%", background: "radial-gradient(circle, rgba(60,140,255,0.4), transparent 65%)"}} />
      <AbsoluteFill style={{transform: `scale(${zoom})`, transformOrigin: "540px 1200px"}}>
        <svg width={1080} height={1920} viewBox="0 0 1080 1920">
          <CityLayer b={BACK} fill="#071433" base={1190} dx={-f * 0.5} lit={0.5} seed="cb" f={f} />
          <CityLayer b={MID} fill="#0a1d4a" base={1190} dx={-f * 1.1} lit={0.7} seed="cm" f={f} />
          <CityLayer b={FRONT} fill="#0d2a66" base={1190} dx={-f * 2.0} lit={0.9} seed="cf" f={f} />
          <rect x={0} y={1190} width={1080} height={150} fill="#050b1c" />
          <rect x={0} y={1188} width={1080} height={3} fill={C.cyan} opacity={0.8} style={{filter: "drop-shadow(0 0 8px #4fd8ff)"}} />
          {Array.from({length: 16}, (_, k) => (
            <rect key={k} x={((k * 140 - f * 14) % 2000 + 2000) % 2000 - 200} y={1262} width={70} height={4} fill={C.ice} opacity={0.4} />
          ))}
          {CARS.map((c, i) => {
            const prog = (c.off * 1800 + f * c.sp) % 1800;
            const x = c.dir > 0 ? prog - 300 : 1500 - prog;
            const y = c.lane === 0 ? 1215 : 1280;
            const front = c.dir > 0 ? x + c.w : x;
            const back = c.dir > 0 ? x : x + c.w;
            const boxS = interpolate(f, [14 + i * 3, 24 + i * 3], [0.6, 1], CL);
            return (
              <g key={i}>
                <polygon points={`${front},${y + 14} ${front + c.dir * 220},${y - 10} ${front + c.dir * 220},${y + 40}`} fill="rgba(180,230,255,0.18)" />
                <rect x={x} y={y} width={c.w} height={34} rx={10} fill="#0a1226" stroke="#2f7dff" strokeWidth={2} />
                <rect x={x + c.w * 0.25} y={y - 18} width={c.w * 0.5} height={22} rx={8} fill="#0a1226" stroke="#2f7dff" strokeWidth={2} />
                <circle cx={front - c.dir * 6} cy={y + 16} r={6} fill="#fff" style={{filter: "drop-shadow(0 0 10px #bfefff)"}} />
                <circle cx={back + c.dir * 6} cy={y + 16} r={5} fill={C.red} style={{filter: "drop-shadow(0 0 10px #ff4d5e)"}} />
                {c.box && (
                  <g opacity={boxS} transform={`translate(${x + c.w / 2} ${y - 10}) scale(${boxS}) translate(${-(x + c.w / 2)} ${-(y - 10)})`}>
                    <rect x={x - 12} y={y - 48} width={c.w + 24} height={96} fill="none" stroke={C.cyan} strokeWidth={3} strokeDasharray="26 14" style={{filter: "drop-shadow(0 0 8px #4fd8ff)"}} />
                    <text x={x - 12} y={y - 58} fontSize={28} fontWeight={700} fill={C.cyan} style={{fontFamily}}>গাড়ি {toBn(90 + ((i * 3 + 5) % 9))}%</text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>
      </AbsoluteFill>
      <Panel x={70} y={290} w={420} delay={10}>
        <div style={{fontSize: 28, opacity: 0.8}}>যানজট বিশ্লেষণ</div>
        <div style={{fontSize: 56, fontWeight: 800, color: C.cyan, textShadow: `0 0 20px ${C.cyan}`}}>−{toBn(Math.floor(interpolate(f, [10, 60], [0, 32], CL)))}%</div>
      </Panel>
      <LowerThird idx="০২" title="স্মার্ট শহর" sub="নিরাপদ ও দ্রুত যাতায়াত" />
    </AbsoluteFill>
  );
};

/* ---------------- C: learning — AI assistant on a phone ---------------- */
const Learn: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const rotY = interpolate(f, [0, 85], [-16, 10], CL);
  const user = spring({frame: f - 12, fps, config: {damping: 16, stiffness: 120}});
  const ai = spring({frame: f - 34, fps, config: {damping: 16, stiffness: 120}});
  const typing = f > 22 && f < 36;
  const words = "মেশিন যখন মানুষের মতো শেখে, ভাবে ও সিদ্ধান্তে সাহায্য করে।".split(" ");
  const chips = [
    {t: "ভাষা অনুবাদ", x: 40, y: 430, d: 20},
    {t: "পড়াশোনা", x: 770, y: 640, d: 28},
    {t: "২৪/৭ সহায়তা", x: 60, y: 960, d: 36},
  ];
  return (
    <AbsoluteFill>
      <div style={{position: "absolute", left: 90, top: 330, width: 900, height: 900, borderRadius: "50%", background: "radial-gradient(circle, rgba(30,144,255,0.35), transparent 65%)"}} />
      <div style={{position: "absolute", left: 260, top: 260, width: 560, height: 1000, borderRadius: 64, border: "4px solid #2a5cff", background: "linear-gradient(180deg,#071634,#030818)", boxShadow: "0 0 70px rgba(30,144,255,0.55), inset 0 0 40px rgba(30,144,255,0.2)", transform: `perspective(1400px) rotateY(${rotY}deg) rotateX(4deg)`, fontFamily, color: "#fff", padding: 30}}>
        <div style={{display: "flex", alignItems: "center", gap: 14, fontSize: 32, fontWeight: 700, color: C.cyan}}>
          <div style={{width: 16, height: 16, borderRadius: 8, background: C.cyan, boxShadow: `0 0 14px ${C.cyan}`}} />
          এআই সহকারী
        </div>
        <div style={{height: 2, background: "rgba(79,216,255,0.3)", margin: "18px 0 30px"}} />
        <div style={{display: "flex", justifyContent: "flex-end", opacity: Math.min(1, user), transform: `translateY(${(1 - user) * 30}px)`}}>
          <div style={{maxWidth: 380, padding: "18px 24px", borderRadius: 28, background: "linear-gradient(135deg,#1e90ff,#0b3dff)", fontSize: 34, fontWeight: 500, lineHeight: 1.5}}>কৃত্রিম বুদ্ধিমত্তা কী?</div>
        </div>
        {typing && (
          <div style={{display: "flex", gap: 10, marginTop: 30}}>
            {[0, 1, 2].map((i) => (
              <div key={i} style={{width: 16, height: 16, borderRadius: 8, background: C.cyan, transform: `translateY(${-8 * Math.abs(Math.sin(f / 4 + i))}px)`}} />
            ))}
          </div>
        )}
        {f >= 34 && (
          <div style={{marginTop: 30, maxWidth: 440, padding: "20px 26px", borderRadius: 28, background: "rgba(30,60,130,0.55)", border: "1.5px solid rgba(79,216,255,0.5)", fontSize: 34, fontWeight: 500, lineHeight: 1.55, opacity: Math.min(1, ai), transform: `translateY(${(1 - ai) * 30}px)`}}>
            {words.map((w, i) => {
              const o = interpolate(f, [38 + i * 3, 42 + i * 3], [0, 1], CL);
              return (
                <span key={i} style={{opacity: o, filter: `blur(${(1 - o) * 6}px)`}}>
                  {w}{" "}
                </span>
              );
            })}
          </div>
        )}
      </div>
      {chips.map((c, i) => {
        const s = spring({frame: f - c.d, fps, config: {damping: 14, stiffness: 100}});
        return (
          <div key={i} style={{position: "absolute", left: c.x, top: c.y + Math.sin(f / 14 + i * 2) * 14, padding: "16px 26px", borderRadius: 40, fontFamily, fontWeight: 700, fontSize: 34, color: C.ice, background: "rgba(14,50,120,0.6)", border: "1.5px solid rgba(79,216,255,0.6)", boxShadow: "0 0 30px rgba(30,144,255,0.45)", opacity: Math.min(1, s), transform: `scale(${0.7 + 0.3 * Math.min(1, s)})`}}>
            {c.t}
          </div>
        );
      })}
      <LowerThird idx="০৩" title="শিক্ষা ও ভাষা" sub="সবার জন্য ব্যক্তিগত সহায়তা" />
    </AbsoluteFill>
  );
};

/** 8–15s: everyday life, three cinematic vignettes with wipe transitions. */
export const Life: React.FC = () => (
  <AbsoluteFill>
    <Sequence from={LIFE[0]} durationInFrames={LIFE[1] - LIFE[0] + 12}>
      <Wipe first>
        <Health />
      </Wipe>
    </Sequence>
    <Sequence from={LIFE[1]} durationInFrames={LIFE[2] - LIFE[1] + 12}>
      <Wipe>
        <City />
      </Wipe>
    </Sequence>
    <Sequence from={LIFE[2]} durationInFrames={LIFE[3] - LIFE[2]}>
      <Wipe>
        <Learn />
      </Wipe>
    </Sequence>
  </AbsoluteFill>
);
