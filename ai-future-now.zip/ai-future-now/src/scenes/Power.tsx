import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {C} from "../theme";
import {CL, easeOut, shake} from "../fx";
import {Kinetic} from "../ui";
import {random} from "remotion";

const SPH = Array.from({length: 520}, (_, i) => {
  const y = 1 - (i / 519) * 2;
  const r = Math.sqrt(1 - y * y);
  const th = i * 2.399963;
  return {x: Math.cos(th) * r, y, z: Math.sin(th) * r};
});

/** 22–27s: dramatic drop — rotating data globe, shockwaves, beat-synced pulses. */
export const Power: React.FC = () => {
  const f = useCurrentFrame();
  const sh = shake(f, 0, 10, 16);
  const cam = f < 55 ? interpolate(f, [0, 55], [1.7, 1.0], {...CL, easing: easeOut}) : interpolate(f, [55, 150], [1.0, 1.12], CL);
  const beatK = Math.exp(-(f % 15) / 4);
  const R = 330 * (1 + 0.025 * beatK);
  const rot = f * 0.014;
  const tilt = 0.35;

  const proj = SPH.map((p) => {
    const x1 = p.x * Math.cos(rot) + p.z * Math.sin(rot);
    const z1 = -p.x * Math.sin(rot) + p.z * Math.cos(rot);
    const y2 = p.y * Math.cos(tilt) - z1 * Math.sin(tilt);
    const z2 = p.y * Math.sin(tilt) + z1 * Math.cos(tilt);
    return {sx: 540 + x1 * R, sy: 800 + y2 * R, d: (z2 + 1) / 2};
  });

  const links: React.ReactNode[] = [];
  for (let k = 0; k < 40; k++) {
    const a = proj[k * 13];
    const b = proj[(k * 13 + 37) % 520];
    if (a.d > 0.55 && b.d > 0.55)
      links.push(<line key={k} x1={a.sx} y1={a.sy} x2={b.sx} y2={b.sy} stroke={C.cyan} strokeWidth={1.5} opacity={0.28} />);
  }

  const sat = f * 0.05;
  const ring = (delay: number) => {
    const r = interpolate(f, [delay, 40 + delay], [40, 1000], {...CL, easing: easeOut});
    const o = interpolate(f, [delay, 40 + delay], [0.9, 0], CL);
    return <div key={delay} style={{position: "absolute", left: 540 - r, top: 800 - r, width: r * 2, height: r * 2, borderRadius: "50%", border: `3px solid ${C.cyan}`, boxShadow: `0 0 40px ${C.blue}`, opacity: o}} />;
  };

  const gl = f >= 50 && f < 58;
  const gdx = gl ? (random(`pg${f}`) - 0.5) * 24 : 0;
  const white = interpolate(f, [135, 150], [0, 0.4], CL);

  return (
    <AbsoluteFill style={{transform: `translate(${sh.x}px, ${sh.y}px)`}}>
      <AbsoluteFill style={{transform: `scale(${cam})`, transformOrigin: "540px 800px"}}>
        {/* rotating light rays */}
        <div style={{position: "absolute", left: -360, top: -100, width: 1800, height: 1800, background: `repeating-conic-gradient(from ${f * 0.3}deg, rgba(79,216,255,0.16) 0deg 4deg, transparent 4deg 18deg)`, WebkitMaskImage: "radial-gradient(circle, black 0%, transparent 62%)", maskImage: "radial-gradient(circle, black 0%, transparent 62%)", mixBlendMode: "screen", opacity: 0.6}} />
        <div style={{position: "absolute", left: 140, top: 400, width: 800, height: 800, borderRadius: "50%", background: "radial-gradient(circle, rgba(30,144,255,0.45), transparent 65%)", opacity: 0.7 + 0.3 * beatK}} />
        <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: "absolute", inset: 0}}>
          <g transform="rotate(-20 540 800)">
            <ellipse cx={540} cy={800} rx={520} ry={140} fill="none" stroke={C.cyan} strokeWidth={2} opacity={0.5} />
            <circle cx={540 + Math.cos(sat) * 520} cy={800 + Math.sin(sat) * 140} r={11} fill="#fff" style={{filter: "drop-shadow(0 0 14px #4fd8ff)"}} />
          </g>
          {links}
          {proj.map((p, i) => (
            <circle key={i} cx={p.sx} cy={p.sy} r={1.5 + 3.2 * p.d} fill={p.d > 0.7 ? "#bfefff" : C.cyan} opacity={0.12 + 0.88 * Math.pow(p.d, 1.5)} />
          ))}
        </svg>
        {ring(0)}
        {ring(8)}
      </AbsoluteFill>

      <div style={{position: "absolute", left: 60, right: 60, top: 1320, display: "flex", justifyContent: "center"}}>
        <Kinetic text="সুযোগ অসীম" start={12} size={138} exit={44} accent={[1]} />
      </div>
      <div style={{position: "absolute", left: 60, right: 60, top: 1320, display: "flex", justifyContent: "center", transform: gl ? `translateX(${gdx}px) skewX(${gdx * 0.4}deg)` : undefined, filter: gl ? "drop-shadow(-7px 0 #ff2d55) drop-shadow(7px 0 #00c8ff)" : undefined}}>
        <Kinetic text="ঝুঁকিও বাস্তব" start={50} size={138} exit={92} accent={[0]} accentColor={C.red} />
      </div>
      <div style={{position: "absolute", left: 60, right: 60, top: 1320, display: "flex", justifyContent: "center"}}>
        <Kinetic text="সিদ্ধান্ত আপনার" start={98} size={138} accent={[1]} accentColor="#fff" />
      </div>
      <AbsoluteFill style={{background: "#fff", opacity: white, mixBlendMode: "screen"}} />
    </AbsoluteFill>
  );
};
