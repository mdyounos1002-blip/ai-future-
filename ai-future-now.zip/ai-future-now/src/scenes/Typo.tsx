import React from "react";
import {AbsoluteFill, Sequence, interpolate, random, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {C} from "../theme";
import {fontFamily} from "../fonts";
import {CL, easeInOut, easeOut} from "../fx";
import {Kinetic} from "../ui";

const DOTS = Array.from({length: 35}, (_, i) => ({x: 165 + (i % 7) * 125, y: 50 + Math.floor(i / 7) * 70, t: 6 + random(`d${i}`) * 26}));

/* ---- motifs (SVG 1080x620) ---- */
const Learn: React.FC<{f: number}> = ({f}) => {
  const prog = interpolate(f, [8, 38], [0, 1], {...CL, easing: easeInOut});
  return (
    <svg width={1080} height={620} viewBox="0 0 1080 620">
      {DOTS.map((d, i) => {
        const lit = interpolate(f, [d.t, d.t + 6], [0, 1], CL);
        return <circle key={i} cx={d.x} cy={d.y} r={9 + 3 * lit} fill={lit > 0.5 ? C.cyan : "#16316e"} style={{filter: lit > 0.5 ? "drop-shadow(0 0 10px #4fd8ff)" : undefined}} />;
      })}
      <path d="M 90 590 C 300 570, 420 500, 540 420 S 820 330, 990 300" pathLength={1} fill="none" stroke="#fff" strokeWidth={6} strokeLinecap="round" strokeDasharray={1} strokeDashoffset={1 - prog} style={{filter: "drop-shadow(0 0 12px #4fd8ff)"}} />
    </svg>
  );
};

const Help: React.FC<{f: number}> = ({f}) => {
  const s = interpolate(f, [0, 16], [0.4, 1], {...CL, easing: easeOut});
  return (
    <svg width={1080} height={620} viewBox="0 0 1080 620">
      <line x1={330} y1={300} x2={750} y2={300} stroke={C.cyan} strokeWidth={3} strokeDasharray="10 14" strokeDashoffset={-f * 2} opacity={0.8} />
      {[0, 1, 2].map((i) => {
        const t = ((f * 0.03 + i / 3) % 1);
        return <circle key={i} cx={330 + 420 * t} cy={300} r={9} fill="#fff" style={{filter: "drop-shadow(0 0 10px #4fd8ff)"}} />;
      })}
      <g transform={`translate(260 300) scale(${s})`}>
        <circle r={95} fill="none" stroke="#fff" strokeWidth={3} strokeDasharray="8 12" transform={`rotate(${f * 2})`} opacity={0.7} />
        <circle r={62} fill="#fff" style={{filter: "drop-shadow(0 0 24px #bfe6ff)"}} />
      </g>
      <g transform={`translate(820 300) scale(${s})`}>
        <circle r={95} fill="none" stroke={C.cyan} strokeWidth={3} strokeDasharray="8 12" transform={`rotate(${-f * 2})`} opacity={0.8} />
        <circle r={62} fill={C.blue} style={{filter: "drop-shadow(0 0 30px #1e90ff)"}} />
        <text y={20} textAnchor="middle" fontSize={56} fontWeight={800} fill="#fff" style={{fontFamily}}>AI</text>
      </g>
      <text x={260} y={470} textAnchor="middle" fontSize={40} fontWeight={700} fill={C.ice} style={{fontFamily}}>মানুষ</text>
    </svg>
  );
};

const TREE: [number, number][] = [[540, 60], [300, 230], [780, 230], [170, 420], [430, 420], [650, 420], [910, 420]];
const TEDGES: [number, number][] = [[0, 1], [0, 2], [1, 3], [1, 4], [2, 5], [2, 6]];
const PATH = new Set([0, 2, 5]);
const Decide: React.FC<{f: number}> = ({f}) => (
  <svg width={1080} height={620} viewBox="0 0 1080 620">
    {TEDGES.map(([a, b], i) => {
      const prog = interpolate(f, [i * 4, i * 4 + 12], [0, 1], CL);
      const on = PATH.has(a) && PATH.has(b);
      const glow = on ? interpolate(f, [26, 36], [0, 1], CL) : 0;
      const A = TREE[a];
      const B = TREE[b];
      return <line key={i} x1={A[0]} y1={A[1]} x2={A[0] + (B[0] - A[0]) * prog} y2={A[1] + (B[1] - A[1]) * prog} stroke={glow > 0 ? "#fff" : "#2f7dff"} strokeWidth={glow > 0 ? 7 : 3} style={{filter: glow > 0 ? "drop-shadow(0 0 12px #4fd8ff)" : undefined}} />;
    })}
    {TREE.map(([x, y], i) => {
      const on = PATH.has(i === 0 ? 0 : i);
      const s = interpolate(f, [i * 4, i * 4 + 10], [0, 1], CL);
      const pulse = on && f > 30 ? 1 + 0.15 * Math.sin(f / 4) : 1;
      return <circle key={i} cx={x} cy={y} r={(on ? 24 : 16) * s * pulse} fill={on ? "#fff" : C.cyan} style={{filter: `drop-shadow(0 0 ${on ? 18 : 8}px #4fd8ff)`}} />;
    })}
  </svg>
);

const Control: React.FC<{f: number}> = ({f}) => {
  const knob = interpolate(f, [0, 60], [200, -90], {...CL, easing: easeOut}) * (Math.PI / 180);
  const pulse = 1 + 0.03 * Math.sin(f / 5);
  return (
    <svg width={1080} height={620} viewBox="0 0 1080 620">
      <g transform={`translate(540 310) scale(${pulse})`}>
        <circle r={235} fill="none" stroke="#2f7dff" strokeWidth={3} strokeDasharray="4 14" transform={`rotate(${f * 0.5})`} />
        <circle r={200} fill="none" stroke={C.cyan} strokeWidth={5} opacity={0.6} style={{filter: "drop-shadow(0 0 14px #4fd8ff)"}} />
        <circle cx={Math.cos(knob) * 200} cy={Math.sin(knob) * 200} r={20} fill="#fff" style={{filter: "drop-shadow(0 0 18px #4fd8ff)"}} />
        <circle cy={-60} r={50} fill="#fff" style={{filter: "drop-shadow(0 0 24px #bfe6ff)"}} />
        <path d="M -105 110 C -105 10 105 10 105 110 Z" fill="#fff" style={{filter: "drop-shadow(0 0 24px #bfe6ff)"}} />
      </g>
    </svg>
  );
};

const MSGS = [
  {s: 4, e: 38, text: "AI শেখে", sub: "লক্ষ লক্ষ উদাহরণ থেকে", accent: [0], Motif: Learn},
  {s: 38, e: 70, text: "AI সাহায্য করে", sub: "কাজ হয় দ্রুত ও সহজ", accent: [0], Motif: Help},
  {s: 70, e: 120, text: "AI সিদ্ধান্তে সহায়তা দেয়", sub: "চূড়ান্ত সিদ্ধান্ত মানুষের", accent: [0], Motif: Decide},
  {s: 120, e: 210, text: "নিয়ন্ত্রণ থাকুক মানুষের হাতে", sub: "", accent: [2], Motif: Control},
];

const Msg: React.FC<{m: (typeof MSGS)[number]; last: boolean}> = ({m, last}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const dur = m.e - m.s;
  const exit = last ? undefined : dur - 10;
  const mo = spring({frame: f, fps, config: {damping: 18, stiffness: 100}});
  const out = last ? 0 : interpolate(f, [dur - 10, dur], [0, 1], CL);
  return (
    <AbsoluteFill>
      <div style={{position: "absolute", left: 0, top: 330, width: 1080, height: 620, opacity: Math.min(1, mo) * (1 - out), transform: `scale(${0.9 + 0.1 * Math.min(1, mo) + out * 0.08})`, filter: out > 0 ? `blur(${out * 12}px)` : undefined}}>
        <m.Motif f={f} />
      </div>
      <div style={{position: "absolute", left: 80, right: 80, top: 990, display: "flex", flexDirection: "column", alignItems: "center", gap: 24}}>
        <Kinetic text={m.text} start={4} size={112} stagger={6} accent={m.accent} exit={exit} />
        {m.sub !== "" && <Kinetic text={m.sub} start={22} size={50} weight={500} color={C.dim} stagger={4} exit={exit} />}
      </div>
    </AbsoluteFill>
  );
};

/** 15–22s: kinetic Bangla typography — four key messages with motifs. */
export const Typo: React.FC = () => {
  const f = useCurrentFrame();
  const stroke = "2px rgba(79,216,255,0.2)";
  return (
    <AbsoluteFill>
      {/* parallax giant outline */}
      <div style={{position: "absolute", left: 0, right: 0, top: 350 - f * 0.9, textAlign: "center", fontFamily, fontWeight: 800, fontSize: 1100, lineHeight: 1, color: "transparent", WebkitTextStroke: stroke, transform: `translateX(${Math.sin(f / 60) * 40}px)`}}>
        AI
      </div>
      {/* diagonal light rays */}
      {[0, 1, 2].map((i) => (
        <div key={i} style={{position: "absolute", top: -200, bottom: -200, width: 170, left: ((f * (2 + i) + i * 420) % 1500) - 300, transform: "skewX(-22deg)", background: "linear-gradient(90deg, transparent, rgba(79,216,255,0.10), transparent)", filter: "blur(20px)"}} />
      ))}
      {MSGS.map((m, i) => (
        <Sequence key={i} from={m.s} durationInFrames={m.e - m.s}>
          <Msg m={m} last={i === MSGS.length - 1} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
