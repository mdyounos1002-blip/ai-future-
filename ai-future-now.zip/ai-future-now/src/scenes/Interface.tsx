import React from "react";
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {C} from "../theme";
import {fontFamily} from "../fonts";
import {CL, bnGroup, easeInOut, toBn} from "../fx";
import {Kinetic, Panel} from "../ui";

const NODES = Array.from({length: 34}, (_, i) => ({
  x: 60 + random(`nx${i}`) * 960,
  y: 260 + random(`ny${i}`) * 1250,
  r: 3 + random(`nr${i}`) * 5,
}));
const EDGES: [number, number][] = [];
NODES.forEach((a, i) => {
  NODES.map((b, j) => ({j, d: Math.hypot(a.x - b.x, a.y - b.y)}))
    .filter((o) => o.j !== i)
    .sort((p, q) => p.d - q.d)
    .slice(0, 2)
    .forEach((o) => {
      if (!EDGES.some((e) => (e[0] === i && e[1] === o.j) || (e[0] === o.j && e[1] === i))) EDGES.push([i, o.j]);
    });
});

const COLS = [34, 96, 982, 1044].map((x, c) => ({
  x,
  text: Array.from({length: 60}, (_, i) => (random(`bin${c}-${i}`) > 0.5 ? "১" : "০")).join("\n"),
}));

/** 3–8s: futuristic AI interface. Three parallax layers + camera push-in. */
export const Interface: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = easeInOut(interpolate(f, [0, 150], [0, 1], CL));
  const intro = spring({frame: f, fps, config: {damping: 20, stiffness: 90}});
  const origin = "540px 800px";
  const scanY = interpolate(f % 75, [0, 75], [200, 1500]);

  const ticks = Array.from({length: 72}, (_, i) => (
    <line key={i} x1={0} y1={-338} x2={0} y2={i % 6 === 0 ? -362 : -350} transform={`rotate(${i * 5})`} stroke={C.cyan} strokeWidth={i % 6 === 0 ? 3 : 1.5} opacity={0.7} />
  ));

  const eq = Array.from({length: 14}, (_, i) => 20 + 60 * Math.abs(Math.sin(f / 6 + i * 0.7) * Math.cos(f / 11 + i)));

  return (
    <AbsoluteFill style={{transform: `scale(${1 + 0.28 * p}) rotate(${-1.6 * p}deg)`, transformOrigin: origin}}>
      {/* FAR: neural network */}
      <AbsoluteFill style={{transform: `scale(${1 + 0.18 * p})`, transformOrigin: origin}}>
        <svg width={1080} height={1920} viewBox="0 0 1080 1920">
          {EDGES.map(([a, b], i) => (
            <line key={i} x1={NODES[a].x} y1={NODES[a].y} x2={NODES[b].x} y2={NODES[b].y} stroke="#3b8bff" strokeWidth={1.5} opacity={interpolate(f, [i * 1.1, i * 1.1 + 14], [0, 0.4], CL)} />
          ))}
          {EDGES.map(([a, b], i) => {
            if (i % 2) return null;
            const t = (f * 0.016 + random(`pk${i}`)) % 1;
            const A = NODES[a];
            const B = NODES[b];
            return <circle key={"p" + i} cx={A.x + (B.x - A.x) * t} cy={A.y + (B.y - A.y) * t} r={4.5} fill="#bfefff" style={{filter: "drop-shadow(0 0 6px #4fd8ff)"}} />;
          })}
          {NODES.map((n, i) => (
            <circle key={i} cx={n.x} cy={n.y} r={n.r * interpolate(f, [i * 1.5, i * 1.5 + 10], [0, 1], CL) * (1 + 0.35 * Math.sin(f / 9 + i))} fill={C.cyan} opacity={0.85} style={{filter: "drop-shadow(0 0 8px #1e90ff)"}} />
          ))}
        </svg>
      </AbsoluteFill>

      {/* falling binary columns */}
      <AbsoluteFill style={{overflow: "hidden", opacity: 0.25}}>
        {COLS.map((c, i) => (
          <div key={i} style={{position: "absolute", left: c.x, top: -((f * 5 + i * 130) % 340), whiteSpace: "pre", fontFamily, fontSize: 26, lineHeight: "34px", color: C.cyan}}>
            {c.text}
          </div>
        ))}
      </AbsoluteFill>

      {/* MID: HUD rings + core */}
      <div style={{position: "absolute", left: 140, top: 400, width: 800, height: 800, opacity: intro, transform: `scale(${(0.5 + 0.5 * intro) * (1 + 0.5 * p)})`}}>
        <svg viewBox="-400 -400 800 800" width={800} height={800}>
          <defs>
            <radialGradient id="core">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="35%" stopColor="#4fd8ff" />
              <stop offset="100%" stopColor="#0b3dff" stopOpacity={0} />
            </radialGradient>
          </defs>
          <g transform={`rotate(${f * 0.4})`}>
            <circle r={370} fill="none" stroke="#2f7dff" strokeWidth={2} strokeDasharray="3 16" opacity={0.8} />
          </g>
          <g transform={`rotate(${-f * 0.8})`}>
            <circle r={310} fill="none" stroke={C.cyan} strokeWidth={3} strokeDasharray="220 60" opacity={0.7} />
          </g>
          <g transform={`rotate(${f * 0.2})`}>{ticks}</g>
          <g transform={`rotate(${f * 2})`}>
            <circle r={250} fill="none" stroke="#9fe8ff" strokeWidth={8} strokeDasharray="260 1311" strokeLinecap="round" style={{filter: "drop-shadow(0 0 12px #4fd8ff)"}} />
          </g>
          <circle r={170 + 10 * Math.sin(f / 10)} fill="url(#core)" opacity={0.9} />
          <text y={42} textAnchor="middle" fontSize={120} fontWeight={800} fill="#fff" style={{fontFamily, filter: "drop-shadow(0 0 18px #4fd8ff)"}}>
            AI
          </text>
        </svg>
      </div>

      {/* scan line */}
      <div style={{position: "absolute", left: 0, right: 0, top: scanY, height: 3, background: `linear-gradient(90deg, transparent, ${C.cyan}, transparent)`, boxShadow: `0 0 26px ${C.cyan}`, opacity: 0.7}} />

      {/* NEAR: glass panels (counter-scaled so they stay readable) */}
      <AbsoluteFill style={{transform: `scale(${1 + 0.1 * p})`, transformOrigin: origin}}>
        <Panel x={70} y={290} w={430} delay={18}>
          <div style={{fontSize: 30, opacity: 0.8}}>ডেটা প্রসেসিং</div>
          <div style={{fontSize: 52, fontWeight: 800, color: C.cyan, textShadow: `0 0 20px ${C.cyan}`}}>{bnGroup(interpolate(f, [10, 150], [2480000, 98765432], CL))}</div>
        </Panel>
        <Panel x={610} y={400} w={400} delay={28}>
          <div style={{fontSize: 30, opacity: 0.8}}>মডেল নির্ভুলতা</div>
          <div style={{fontSize: 52, fontWeight: 800, color: "#fff"}}>{toBn(interpolate(f, [10, 140], [91.2, 98.6], CL).toFixed(1))}%</div>
          <div style={{height: 8, borderRadius: 4, background: "rgba(79,216,255,0.2)", marginTop: 8}}>
            <div style={{height: 8, borderRadius: 4, width: `${interpolate(f, [10, 140], [91, 98.6], CL)}%`, background: C.cyan, boxShadow: `0 0 14px ${C.cyan}`}} />
          </div>
        </Panel>
        <Panel x={610} y={1010} w={400} delay={38}>
          <div style={{fontSize: 28, opacity: 0.8, marginBottom: 8}}>লাইভ সিগন্যাল</div>
          <div style={{display: "flex", alignItems: "flex-end", gap: 8, height: 80}}>
            {eq.map((h, i) => (
              <div key={i} style={{flex: 1, height: h, borderRadius: 3, background: `linear-gradient(180deg, ${C.cyan}, ${C.deep})`}} />
            ))}
          </div>
        </Panel>
      </AbsoluteFill>

      {/* caption (not affected by parallax) */}
      <div style={{position: "absolute", left: 80, right: 80, top: 1340, display: "flex", flexDirection: "column", alignItems: "center", transform: `scale(${1 / (1 + 0.28 * p)}) rotate(${1.6 * p}deg)`, transformOrigin: "50% 0%"}}>
        <Kinetic text="কৃত্রিম বুদ্ধিমত্তা" start={10} size={54} weight={700} color={C.cyan} stagger={6} />
        <Kinetic text="প্রতি সেকেন্ডে কোটি কোটি তথ্য বিশ্লেষণ" start={34} stagger={6} size={80} accent={[2, 3]} style={{marginTop: 10}} />
      </div>
    </AbsoluteFill>
  );
};
